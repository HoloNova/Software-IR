import json,os,shutil
from pathlib import Path
facts={"uid":os.getuid(),"memory_max":Path("/sys/fs/cgroup/memory.max").read_text().strip(),"cpu_max":Path("/sys/fs/cgroup/cpu.max").read_text().strip(),"java":shutil.which("java"),"mvn":shutil.which("mvn")}
assert facts["uid"] != 0
assert int(facts["memory_max"]) == 256*1024**2
quota,period=map(int,facts["cpu_max"].split());assert quota/period == 0.5
Path("smoke.json").write_text(json.dumps(facts))
print(json.dumps(facts),flush=True)
